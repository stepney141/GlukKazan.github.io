Dagaz.AI.SGF = Dagaz.Model.parseSgf("(;W[b1c2](;B[b3b2])(;B[a4a3]))");
